//
//  AppDelegate.h
//  SCTabView
//
//  Created by Sunc on 16/7/21.
//  Copyright © 2016年 Sunc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

